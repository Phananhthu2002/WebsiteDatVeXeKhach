﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace QuanLyDatVeXeKhach09.Models
{
    public partial class QuanLyDatVeXeKhachContext : DbContext
    {
        public QuanLyDatVeXeKhachContext()
        {
        }

        public QuanLyDatVeXeKhachContext(DbContextOptions<QuanLyDatVeXeKhachContext> options)
            : base(options)
        {
        }

        public virtual DbSet<ChiTietVeXe> ChiTietVeXes { get; set; }
        public virtual DbSet<ChiTietXe> ChiTietXes { get; set; }
        public virtual DbSet<ChuyenXe> ChuyenXes { get; set; }
        public virtual DbSet<KhachHang> KhachHangs { get; set; }
        public virtual DbSet<LoaiXeKhach> LoaiXeKhaches { get; set; }
        public virtual DbSet<NhanVien> NhanViens { get; set; }
        public virtual DbSet<QuyenThamChieu> QuyenThamChieus { get; set; }
        public virtual DbSet<TaiXe> TaiXes { get; set; }
        public virtual DbSet<TuyenXe> TuyenXes { get; set; }
        public virtual DbSet<VeXe> VeXes { get; set; }
        public virtual DbSet<Xe> Xes { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Data Source=.;Initial Catalog=QuanLyDatVeXeKhach;Integrated Security=True");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<ChiTietVeXe>(entity =>
            {
                entity.HasKey(e => e.MaCtvx);

                entity.ToTable("ChiTietVeXe");

                entity.Property(e => e.MaCtvx)
                    .ValueGeneratedNever()
                    .HasColumnName("MaCTVX")
                    .HasComment("Mã Chi Tiết Vé Xe");

                entity.Property(e => e.GhiChu)
                    .HasColumnType("text")
                    .HasComment("GhiChu");

                entity.Property(e => e.MaKh)
                    .HasColumnName("MaKH")
                    .HasComment("Mã Khách Hàng");

                entity.Property(e => e.MaVe)
                    .IsRequired()
                    .HasMaxLength(5)
                    .HasComment("Mã Vé");

                entity.Property(e => e.NgayXuatVe).HasColumnType("date");

                entity.Property(e => e.SoLuong).HasComment("Số Lượng ");

                entity.Property(e => e.ThanhTien)
                    .HasColumnType("decimal(18, 0)")
                    .HasComment("Thành Tiền");

                entity.HasOne(d => d.MaKhNavigation)
                    .WithMany(p => p.ChiTietVeXes)
                    .HasForeignKey(d => d.MaKh)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ChiTietVeXe_KhachHang");

                entity.HasOne(d => d.MaVeNavigation)
                    .WithMany(p => p.ChiTietVeXes)
                    .HasForeignKey(d => d.MaVe)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ChiTietVeXe_VeXe");
            });

            modelBuilder.Entity<ChiTietXe>(entity =>
            {
                entity.HasKey(e => new { e.MaLoaiXe, e.MaXe });

                entity.ToTable("ChiTietXe");

                entity.Property(e => e.MaLoaiXe).HasComment("Mã Loại Xe");

                entity.Property(e => e.MaXe).HasComment("Mã Xe");

                entity.Property(e => e.BienSoXe)
                    .IsRequired()
                    .HasMaxLength(15)
                    .IsFixedLength(true)
                    .HasComment("Biển Số Xe");

                entity.Property(e => e.GhiChu)
                    .HasColumnType("text")
                    .HasComment("Ghi Chú");

                entity.Property(e => e.SoGhe).HasComment("Số Ghế");

                entity.HasOne(d => d.MaLoaiXeNavigation)
                    .WithMany(p => p.ChiTietXes)
                    .HasForeignKey(d => d.MaLoaiXe)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ChiTietXe_LoaiXeKhach");

                entity.HasOne(d => d.MaXeNavigation)
                    .WithMany(p => p.ChiTietXes)
                    .HasForeignKey(d => d.MaXe)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ChiTietXe_Xe");
            });

            modelBuilder.Entity<ChuyenXe>(entity =>
            {
                entity.HasKey(e => e.MaChuyenXe);

                entity.ToTable("ChuyenXe");

                entity.Property(e => e.MaChuyenXe)
                    .HasMaxLength(5)
                    .HasComment("Mã Chuyến Xe");

                entity.Property(e => e.GheTrong).HasComment("Ghế Trống");

                entity.Property(e => e.GhiChu)
                    .HasColumnType("text")
                    .HasComment("Ghi Chú");

                entity.Property(e => e.GioDen)
                    .HasColumnType("time(6)")
                    .HasComment("Giờ Đến");

                entity.Property(e => e.GioKhoiHanh)
                    .HasColumnType("time(6)")
                    .HasComment("Giờ Khởi Hành");

                entity.Property(e => e.MaTuyen).HasComment("Mã Tuyến");

                entity.Property(e => e.MaTx)
                    .IsRequired()
                    .HasMaxLength(5)
                    .HasColumnName("MaTX")
                    .HasComment("Mã Tài Xế");

                entity.HasOne(d => d.MaTuyenNavigation)
                    .WithMany(p => p.ChuyenXes)
                    .HasForeignKey(d => d.MaTuyen)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ChuyenXe_TuyenXe");

                entity.HasOne(d => d.MaTxNavigation)
                    .WithMany(p => p.ChuyenXes)
                    .HasForeignKey(d => d.MaTx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ChuyenXe_TaiXe");
            });

            modelBuilder.Entity<KhachHang>(entity =>
            {
                entity.HasKey(e => e.MaKh)
                    .HasName("PK_KhachHang_1");

                entity.ToTable("KhachHang");

                entity.Property(e => e.MaKh)
                    .HasColumnName("MaKH")
                    .HasComment("Mã Khách Hàng");

                entity.Property(e => e.Cccd)
                    .IsRequired()
                    .HasMaxLength(12)
                    .IsUnicode(false)
                    .HasColumnName("CCCD")
                    .HasComment("Căn Cước Công Dân");

                entity.Property(e => e.DiaChi)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasComment("Địa Chỉ");

                entity.Property(e => e.Email)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.GhiChu)
                    .HasColumnType("text")
                    .HasComment("Ghi Chú");

                entity.Property(e => e.GioiTinh)
                    .IsRequired()
                    .HasMaxLength(5)
                    .HasComment("Giới Tính");

                entity.Property(e => e.HoKh)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("HoKH")
                    .HasComment("Họ Khách Hàng");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.MatKhau)
                    .IsRequired()
                    .HasMaxLength(5)
                    .HasComment("Mật Khẩu");

                entity.Property(e => e.NgaySinh)
                    .HasColumnType("date")
                    .HasComment("Ngày Sinh");

                entity.Property(e => e.Sdt)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("SDT")
                    .HasComment("Số Điện Thoại");

                entity.Property(e => e.TenDangNhap)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasComment("Tên Đăng Nhập");

                entity.Property(e => e.TenKh)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("TenKH")
                    .HasComment("Tên Khách Hàng");

                entity.HasOne(d => d.IdNavigation)
                    .WithMany(p => p.KhachHangs)
                    .HasForeignKey(d => d.Id)
                    .HasConstraintName("FK_KhachHang_QuyenThamChieu");
            });

            modelBuilder.Entity<LoaiXeKhach>(entity =>
            {
                entity.HasKey(e => e.MaLoaiXe);

                entity.ToTable("LoaiXeKhach");

                entity.Property(e => e.MaLoaiXe)
                    .ValueGeneratedNever()
                    .HasComment("Mã Loại Xe");

                entity.Property(e => e.GhiChu)
                    .HasColumnType("text")
                    .HasComment("Ghi Chú");

                entity.Property(e => e.TenLoaiXe)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasComment("Tên Loại Xe");
            });

            modelBuilder.Entity<NhanVien>(entity =>
            {
                entity.HasKey(e => e.MaNv);

                entity.ToTable("NhanVien");

                entity.Property(e => e.MaNv)
                    .HasMaxLength(5)
                    .HasColumnName("MaNV");

                entity.Property(e => e.Cccd)
                    .IsRequired()
                    .HasMaxLength(12)
                    .HasColumnName("CCCD");

                entity.Property(e => e.DiaChi)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Email).HasMaxLength(30);

                entity.Property(e => e.GhiChu).HasColumnType("ntext");

                entity.Property(e => e.GioiTinh)
                    .IsRequired()
                    .HasMaxLength(10);

                entity.Property(e => e.HoNv)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("HoNV");

                entity.Property(e => e.NgaySinh).HasColumnType("date");

                entity.Property(e => e.Sdt)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasColumnName("SDT");

                entity.Property(e => e.TenNv)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("TenNV");
            });

            modelBuilder.Entity<QuyenThamChieu>(entity =>
            {
                entity.ToTable("QuyenThamChieu");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.MatKhau)
                    .IsRequired()
                    .HasMaxLength(5);

                entity.Property(e => e.TenDangNhap)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<TaiXe>(entity =>
            {
                entity.HasKey(e => e.MaTx);

                entity.ToTable("TaiXe");

                entity.Property(e => e.MaTx)
                    .HasMaxLength(5)
                    .HasColumnName("MaTX")
                    .HasComment("Mã Tài Xế");

                entity.Property(e => e.Cccd)
                    .IsRequired()
                    .HasMaxLength(12)
                    .HasColumnName("CCCD")
                    .IsFixedLength(true)
                    .HasComment("Căn Cước Công Dân");

                entity.Property(e => e.DiaChi)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasComment("Địa Chỉ");

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(30);

                entity.Property(e => e.GhiChu)
                    .HasColumnType("text")
                    .HasComment("Ghi Chú");

                entity.Property(e => e.GioiTinh)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasComment("Giới Tính");

                entity.Property(e => e.HoTx)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("HoTX")
                    .HasComment("Họ Tài Xế");

                entity.Property(e => e.NgaySinh)
                    .HasColumnType("date")
                    .HasComment("Ngày Sinh");

                entity.Property(e => e.Sdt)
                    .IsRequired()
                    .HasMaxLength(10)
                    .HasColumnName("SDT")
                    .IsFixedLength(true)
                    .HasComment("Số Điện Thoại");

                entity.Property(e => e.TenTx)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasColumnName("TenTX")
                    .IsFixedLength(true)
                    .HasComment("Tên Tài Xế");
            });

            modelBuilder.Entity<TuyenXe>(entity =>
            {
                entity.HasKey(e => e.MaTuyen);

                entity.ToTable("TuyenXe");

                entity.Property(e => e.MaTuyen).HasComment("Mã Tuyến");

                entity.Property(e => e.BangGia)
                    .HasColumnType("decimal(18, 0)")
                    .HasComment("Bảng Giá");

                entity.Property(e => e.DiemDen)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasComment("Điểm Đến");

                entity.Property(e => e.DiemKhoiHanh)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasComment("Điểm Khởi Hành");

                entity.Property(e => e.GhiChu)
                    .HasColumnType("text")
                    .HasComment("Ghi Chú");

                entity.Property(e => e.MaXe).HasComment("Mã Xe");

                entity.Property(e => e.TenTuyen)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasComment("Tên Tuyến");

                entity.HasOne(d => d.MaXeNavigation)
                    .WithMany(p => p.TuyenXes)
                    .HasForeignKey(d => d.MaXe)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_TuyenXe_Xe");
            });

            modelBuilder.Entity<VeXe>(entity =>
            {
                entity.HasKey(e => e.MaVe);

                entity.ToTable("VeXe");

                entity.Property(e => e.MaVe)
                    .HasMaxLength(5)
                    .HasComment("Mã Vé");

                entity.Property(e => e.GhiChu)
                    .HasColumnType("text")
                    .HasComment("Ghi Chú");

                entity.Property(e => e.MaChuyenXe)
                    .IsRequired()
                    .HasMaxLength(5)
                    .HasComment("Mã Chuyến Xe");

                entity.Property(e => e.MaNv)
                    .IsRequired()
                    .HasMaxLength(5)
                    .HasColumnName("MaNV")
                    .HasComment("Mã Nhân Viên Bán Vé");

                entity.HasOne(d => d.MaChuyenXeNavigation)
                    .WithMany(p => p.VeXes)
                    .HasForeignKey(d => d.MaChuyenXe)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_VeXe_ChuyenXe");

                entity.HasOne(d => d.MaNvNavigation)
                    .WithMany(p => p.VeXes)
                    .HasForeignKey(d => d.MaNv)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_VeXe_NhanVien");
            });

            modelBuilder.Entity<Xe>(entity =>
            {
                entity.HasKey(e => e.MaXe);

                entity.ToTable("Xe");

                entity.Property(e => e.MaXe)
                    .ValueGeneratedNever()
                    .HasComment("Mã Xe");

                entity.Property(e => e.GhiChu)
                    .HasColumnType("text")
                    .HasComment("Ghi Chú");

                entity.Property(e => e.TenXe)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasComment("Tên Xe");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
