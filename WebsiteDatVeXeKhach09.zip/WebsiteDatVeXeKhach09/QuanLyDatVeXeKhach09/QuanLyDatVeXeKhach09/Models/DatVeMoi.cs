﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuanLyDatVeXeKhach09.Models
{
    public class DatVeMoi
    {
        public string MaVe { get; set; }
        public string MaNv { get; set; }
        public string MaChuyenXe { get; set; }
    }
}
