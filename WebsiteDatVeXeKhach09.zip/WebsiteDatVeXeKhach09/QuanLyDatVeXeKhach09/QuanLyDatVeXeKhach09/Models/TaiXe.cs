﻿using System;
using System.Collections.Generic;

#nullable disable

namespace QuanLyDatVeXeKhach09.Models
{
    public partial class TaiXe
    {
        public TaiXe()
        {
            ChuyenXes = new HashSet<ChuyenXe>();
        }

        public string MaTx { get; set; }
        public string HoTx { get; set; }
        public string TenTx { get; set; }
        public DateTime NgaySinh { get; set; }
        public string GioiTinh { get; set; }
        public string DiaChi { get; set; }
        public string Cccd { get; set; }
        public string Sdt { get; set; }
        public string Email { get; set; }
        public string GhiChu { get; set; }

        public virtual ICollection<ChuyenXe> ChuyenXes { get; set; }
    }
}
