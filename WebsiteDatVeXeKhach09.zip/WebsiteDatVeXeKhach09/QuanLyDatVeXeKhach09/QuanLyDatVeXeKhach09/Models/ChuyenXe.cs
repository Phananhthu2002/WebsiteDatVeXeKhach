﻿using System;
using System.Collections.Generic;

#nullable disable

namespace QuanLyDatVeXeKhach09.Models
{
    public partial class ChuyenXe
    {
        public ChuyenXe()
        {
            VeXes = new HashSet<VeXe>();
        }

        public string MaChuyenXe { get; set; }
        public int MaTuyen { get; set; }
        public TimeSpan GioKhoiHanh { get; set; }
        public TimeSpan GioDen { get; set; }
        public int GheTrong { get; set; }
        public string MaTx { get; set; }
        public string GhiChu { get; set; }

        public virtual TuyenXe MaTuyenNavigation { get; set; }
        public virtual TaiXe MaTxNavigation { get; set; }
        public virtual ICollection<VeXe> VeXes { get; set; }
    }
}
