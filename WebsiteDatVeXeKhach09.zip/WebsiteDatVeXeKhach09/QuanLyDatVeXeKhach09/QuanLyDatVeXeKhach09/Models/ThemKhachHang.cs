﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuanLyDatVeXeKhach09.Models
{
    public class ThemKhachHang
    {
        public int MaKh { get; set; }
        public string TenDangNhap { get; set; }
        public string MatKhau { get; set; }
        public string HoKh { get; set; }
        public string TenKh { get; set; }
        public DateTime NgaySinh { get; set; }
        public string GioiTinh { get; set; }
        public string DiaChi { get; set; }
        public string Sdt { get; set; }
        public string Email { get; set; }
        public string Cccd { get; set; }
        public string GhiChu { get; set; }
    }
}
