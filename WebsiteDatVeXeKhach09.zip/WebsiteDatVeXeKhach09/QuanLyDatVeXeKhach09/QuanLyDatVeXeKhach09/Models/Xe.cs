﻿using System;
using System.Collections.Generic;

#nullable disable

namespace QuanLyDatVeXeKhach09.Models
{
    public partial class Xe
    {
        public Xe()
        {
            ChiTietXes = new HashSet<ChiTietXe>();
            TuyenXes = new HashSet<TuyenXe>();
        }

        public int MaXe { get; set; }
        public string TenXe { get; set; }
        public string GhiChu { get; set; }

        public virtual ICollection<ChiTietXe> ChiTietXes { get; set; }
        public virtual ICollection<TuyenXe> TuyenXes { get; set; }
    }
}
