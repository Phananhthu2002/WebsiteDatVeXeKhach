﻿using System;
using System.Collections.Generic;

#nullable disable

namespace QuanLyDatVeXeKhach09.Models
{
    public partial class VeXe
    {
        public VeXe()
        {
            ChiTietVeXes = new HashSet<ChiTietVeXe>();
        }

        public string MaVe { get; set; }
        public string MaNv { get; set; }
        public string MaChuyenXe { get; set; }
        public string GhiChu { get; set; }

        public virtual ChuyenXe MaChuyenXeNavigation { get; set; }
        public virtual NhanVien MaNvNavigation { get; set; }
        public virtual ICollection<ChiTietVeXe> ChiTietVeXes { get; set; }
    }
}
