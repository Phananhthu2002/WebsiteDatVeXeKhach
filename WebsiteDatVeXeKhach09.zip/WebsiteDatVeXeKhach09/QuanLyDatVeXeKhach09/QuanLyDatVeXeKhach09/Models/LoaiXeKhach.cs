﻿using System;
using System.Collections.Generic;

#nullable disable

namespace QuanLyDatVeXeKhach09.Models
{
    public partial class LoaiXeKhach
    {
        public LoaiXeKhach()
        {
            ChiTietXes = new HashSet<ChiTietXe>();
        }

        public int MaLoaiXe { get; set; }
        public string TenLoaiXe { get; set; }
        public string GhiChu { get; set; }

        public virtual ICollection<ChiTietXe> ChiTietXes { get; set; }
    }
}
