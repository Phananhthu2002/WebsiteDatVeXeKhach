﻿using System;
using System.Collections.Generic;

#nullable disable

namespace QuanLyDatVeXeKhach09.Models
{
    public partial class ChiTietVeXe
    {
        public int MaCtvx { get; set; }
        public string MaVe { get; set; }
        public int MaKh { get; set; }
        public int SoLuong { get; set; }
        public decimal ThanhTien { get; set; }
        public DateTime? NgayXuatVe { get; set; }
        public string GhiChu { get; set; }

        public virtual KhachHang MaKhNavigation { get; set; }
        public virtual VeXe MaVeNavigation { get; set; }
    }
}
