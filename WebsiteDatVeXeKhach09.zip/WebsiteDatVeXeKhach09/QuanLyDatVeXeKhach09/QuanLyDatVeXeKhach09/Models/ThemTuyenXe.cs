﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuanLyDatVeXeKhach09.Models
{
    public class ThemTuyenXe
    {
        public int MaTuyen { get; set; }
        public string TenTuyen { get; set; }
        public string DiemKhoiHanh { get; set; }
        public string DiemDen { get; set; }
        public decimal BangGia { get; set; }
        public int MaXe { get; set; }
        public string GhiChu { get; set; }
    }
}
