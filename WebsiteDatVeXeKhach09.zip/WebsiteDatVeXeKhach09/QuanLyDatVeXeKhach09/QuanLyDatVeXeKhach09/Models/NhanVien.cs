﻿using System;
using System.Collections.Generic;

#nullable disable

namespace QuanLyDatVeXeKhach09.Models
{
    public partial class NhanVien
    {
        public NhanVien()
        {
            VeXes = new HashSet<VeXe>();
        }

        public string MaNv { get; set; }
        public string HoNv { get; set; }
        public string TenNv { get; set; }
        public DateTime NgaySinh { get; set; }
        public string GioiTinh { get; set; }
        public string DiaChi { get; set; }
        public string Cccd { get; set; }
        public string Sdt { get; set; }
        public string Email { get; set; }
        public string GhiChu { get; set; }

        public virtual ICollection<VeXe> VeXes { get; set; }
    }
}
