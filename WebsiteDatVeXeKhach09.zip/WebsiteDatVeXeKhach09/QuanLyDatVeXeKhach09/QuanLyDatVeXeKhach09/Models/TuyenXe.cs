﻿using System;
using System.Collections.Generic;

#nullable disable

namespace QuanLyDatVeXeKhach09.Models
{
    public partial class TuyenXe
    {
        public TuyenXe()
        {
            ChuyenXes = new HashSet<ChuyenXe>();
        }

        public int MaTuyen { get; set; }
        public string TenTuyen { get; set; }
        public string DiemKhoiHanh { get; set; }
        public string DiemDen { get; set; }
        public decimal BangGia { get; set; }
        public int MaXe { get; set; }
        public string GhiChu { get; set; }

        public virtual Xe MaXeNavigation { get; set; }
        public virtual ICollection<ChuyenXe> ChuyenXes { get; set; }
    }
}
