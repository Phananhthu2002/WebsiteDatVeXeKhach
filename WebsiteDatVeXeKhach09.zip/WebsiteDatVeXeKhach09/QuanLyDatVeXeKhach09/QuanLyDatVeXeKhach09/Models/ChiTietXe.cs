﻿using System;
using System.Collections.Generic;

#nullable disable

namespace QuanLyDatVeXeKhach09.Models
{
    public partial class ChiTietXe
    {
        public int MaLoaiXe { get; set; }
        public int MaXe { get; set; }
        public string BienSoXe { get; set; }
        public int SoGhe { get; set; }
        public string GhiChu { get; set; }

        public virtual LoaiXeKhach MaLoaiXeNavigation { get; set; }
        public virtual Xe MaXeNavigation { get; set; }
    }
}
