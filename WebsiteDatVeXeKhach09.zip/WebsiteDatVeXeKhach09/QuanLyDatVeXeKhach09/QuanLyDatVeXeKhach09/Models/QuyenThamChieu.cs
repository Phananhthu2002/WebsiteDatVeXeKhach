﻿using System;
using System.Collections.Generic;

#nullable disable

namespace QuanLyDatVeXeKhach09.Models
{
    public partial class QuyenThamChieu
    {
        public QuyenThamChieu()
        {
            KhachHangs = new HashSet<KhachHang>();
        }

        public int Id { get; set; }
        public string TenDangNhap { get; set; }
        public string MatKhau { get; set; }

        public virtual ICollection<KhachHang> KhachHangs { get; set; }
    }
}
