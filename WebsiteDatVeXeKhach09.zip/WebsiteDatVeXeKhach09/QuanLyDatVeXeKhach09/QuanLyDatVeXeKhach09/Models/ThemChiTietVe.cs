﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuanLyDatVeXeKhach09.Models
{
    public class ThemChiTietVe
    {
        public int MaCtvx { get; set; }
        public string MaVe { get; set; }
        public int MaKh { get; set; }
        public int SoLuong { get; set; }
        public decimal ThanhTien { get; set; }
        public DateTime? NgayXuatVe { get; set; }
        public string GhiChu { get; set; }
    }
}
