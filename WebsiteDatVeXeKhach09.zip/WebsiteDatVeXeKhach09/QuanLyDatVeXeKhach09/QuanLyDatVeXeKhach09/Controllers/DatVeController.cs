﻿using Microsoft.AspNetCore.Mvc;
using QuanLyDatVeXeKhach09.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace QuanLyDatVeXeKhach09.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DatVeController : ControllerBase
    {
        QuanLyDatVeXeKhachContext da = new QuanLyDatVeXeKhachContext();

        [HttpGet("get-all-tickets")]
        public IActionResult LayDanhSachVe()
        {
            var ds = da.VeXes.ToList();
            return Ok(ds);
        }

        [HttpGet("get-ticket-by-id")]
        public IActionResult LayThongTinVeBangID(string id)
        {
            var ds = da.VeXes.FirstOrDefault(s => s.MaVe == id);
            return Ok(ds);
        }

        // POST api/<DatVeController>
        [HttpPost("add-new-ticket")]
        public void ThemMoiVe([FromBody] DatVeMoi datVe)
        {
            VeXe t = new VeXe();
            t.MaVe = datVe.MaVe;
            t.MaNv = datVe.MaNv;
            t.MaChuyenXe = datVe.MaChuyenXe;

            da.VeXes.Add(t);
            da.SaveChanges();
        }


        // PUT api/<DatVeController>/5
        [HttpPut("edit-tickets")]
        public void ThayDoiVe(string id, [FromBody] ThayDoiVe datVe)
        {
            VeXe t = da.VeXes.FirstOrDefault(s => s.MaVe == datVe.MaVe);
            t.MaVe = datVe.MaVe;
            t.MaNv = datVe.MaNv;
            t.MaChuyenXe = datVe.MaChuyenXe;

            da.VeXes.Update(t);
            da.SaveChanges();
        }

        // DELETE api/<DatVeController>/5
        [HttpDelete("delete-tickets")]
        public void XoaVe(string id)
        {
            VeXe t = da.VeXes.FirstOrDefault(s => s.MaVe == id);

            da.VeXes.Remove(t);
            da.SaveChanges();
        }
    }
}
