﻿using Microsoft.AspNetCore.Mvc;
using QuanLyDatVeXeKhach09.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace QuanLyDatVeXeKhach09.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ChiTietDatVeController : ControllerBase
    {
        QuanLyDatVeXeKhachContext da = new QuanLyDatVeXeKhachContext();

        [HttpGet("get-all-detail")]
        public IActionResult DanhSachChiTietVe()
        {
            var ds = da.ChiTietVeXes.ToList();
            return Ok(ds);
        }

        [HttpGet("get-detail-by-id")]
        public IActionResult LayDanhSachChiTietVeBangID(int id)
        {
            var ds = da.ChiTietVeXes.FirstOrDefault(s => s.MaCtvx == id);
            return Ok(ds);
        }

        // POST api/<ChiTietDatVeController>
        [HttpPost("add-new-detail")]
        public void ThemChiTietVeXe([FromBody] ThemChiTietVe chiTietVe)
        {
            ChiTietVeXe d = new ChiTietVeXe();
            d.MaCtvx = chiTietVe.MaCtvx;
            d.MaVe = chiTietVe.MaVe;
            d.MaKh = chiTietVe.MaKh;
            d.SoLuong = chiTietVe.SoLuong;
            d.ThanhTien = chiTietVe.ThanhTien;
            d.NgayXuatVe = chiTietVe.NgayXuatVe;

            da.ChiTietVeXes.Add(d);
            da.SaveChanges();
        }

        // PUT api/<ChiTietDatVeController>/5
        [HttpPut("edit-detail")]
        public void ThayDoiChiTietVe(int id, [FromBody] ThayDoiChiTietVe chiTietVe)
        {
            ChiTietVeXe d = da.ChiTietVeXes.FirstOrDefault(s => s.MaCtvx == chiTietVe.MaCtvx);
            d.MaCtvx = chiTietVe.MaCtvx;
            d.MaVe = chiTietVe.MaVe;
            d.MaKh = chiTietVe.MaKh;
            d.SoLuong = chiTietVe.SoLuong;
            d.ThanhTien = chiTietVe.ThanhTien;
            d.NgayXuatVe = chiTietVe.NgayXuatVe;

            da.ChiTietVeXes.Update(d);
            da.SaveChanges();
        }

        // DELETE api/<ChiTietDatVeController>/5
        [HttpDelete("delete-detail")]
        public void XoaChiTietVe(int id)
        {
            ChiTietVeXe d = da.ChiTietVeXes.FirstOrDefault(s => s.MaCtvx == id);

            da.ChiTietVeXes.Remove(d);
            da.SaveChanges();
        }

        //Thống kê doanh thu theo thang nhập vào
        [HttpPost("total-by-month")]
        public IActionResult CalTotalByMonth(int month)
        {
            var ds = da.ChiTietVeXes.Where(s => s.NgayXuatVe.Value.Month == month)
                .Join(da.ChiTietVeXes, o => o.MaCtvx, d => d.MaCtvx, (o, d) =>
                    new
                    {
                        month = o.NgayXuatVe.Value.Month,
                        total = d.ThanhTien
                    })
                .GroupBy(g => g.month)
                .Select(g => new { g.Key, total = g.Sum(s => s.total) });
            return Ok(ds);
        }

    }
}
