﻿using Microsoft.AspNetCore.Mvc;
using QuanLyDatVeXeKhach09.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace QuanLyDatVeXeKhach09.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class KhachHangController : ControllerBase
    {
        QuanLyDatVeXeKhachContext da = new QuanLyDatVeXeKhachContext();

        [HttpGet("get-all-customer")]
        public IActionResult DanhSachKhachHang()
        {
            var ds = da.KhachHangs.ToList();
            return Ok(ds);
        }

        [HttpGet("get-customer-by-id")]
        public IActionResult LayDanhSachKhachHangBangMaKH(int id)
        {
            var ds = da.KhachHangs.FirstOrDefault(s => s.MaKh == id);
            return Ok(ds);
        }

        [HttpGet("get-customer-no-order")]
        public IActionResult DanhSachKHChuaDatVe()
        {
            using (var trans = new QuanLyDatVeXeKhachContext())
            {
                var ds = da.KhachHangs.FromSqlRaw("exec spDSKHChuaDatVe").ToList();
                return Ok(ds);
            }
        } 
             
        // POST api/<KhachHangController>
        [HttpPost("add-new-customer")]
        public void ThemMoiKhachHang([FromBody] ThemKhachHang khachHang)
        {
            KhachHang c = new KhachHang();
            //c.MaKh = khachHang.MaKh;
            c.TenDangNhap = khachHang.TenDangNhap;
            c.MatKhau = khachHang.MatKhau;
            c.HoKh = khachHang.HoKh;
            c.TenKh = khachHang.TenKh;
            c.NgaySinh = khachHang.NgaySinh;
            c.GioiTinh = khachHang.GioiTinh;
            c.DiaChi = khachHang.DiaChi;
            c.Sdt = khachHang.Sdt;
            c.Email = khachHang.Email;
            c.Cccd = khachHang.Cccd;

            da.KhachHangs.Add(c);
            da.SaveChanges();
        }

        // PUT api/<KhachHangController>/5
        [HttpPut("edit-customer")]
        public void ChinhSuaKhachHang(int id, [FromBody] ThayDoiThongTinKH khachHang)
        {
            KhachHang c = da.KhachHangs.FirstOrDefault(s => s.MaKh == khachHang.MaKh);
            c.TenDangNhap = khachHang.TenDangNhap;
            c.MatKhau = khachHang.MatKhau;
            c.HoKh = khachHang.HoKh;
            c.TenKh = khachHang.TenKh;
            c.NgaySinh = khachHang.NgaySinh;
            c.GioiTinh = khachHang.GioiTinh;
            c.DiaChi = khachHang.DiaChi;
            c.Sdt = khachHang.Sdt;
            c.Email = khachHang.Email;
            c.Cccd = khachHang.Cccd;

            da.KhachHangs.Update(c);
            da.SaveChanges();
        }

        // DELETE api/<KhachHangController>/5
        [HttpDelete("delete-customer")]
        public void XoaKhachHang(int id)
        {
            KhachHang c = da.KhachHangs.FirstOrDefault(s => s.MaKh == id);

            da.KhachHangs.Remove(c);
            da.SaveChanges();
        }

        //Thống kê số lương đơn hàng theo từng khách hàng
        [HttpPost("cal-details-by-customer")]
        public IActionResult CalDetailByCustomer()
        {
            var ds = da.ChiTietVeXes.GroupBy(s => s.MaKh).Select(g => new { g.Key, s1 = g.Count() });
            var totalCus = ds.Count();
            var totalOrders = ds.ToList().Sum(s => s.s1);
            var res = new
            {
                Data = ds,
                TotalCus = totalCus,
                TotalOrders = totalOrders
            };
            return Ok(res);
        }

    }
}
