﻿using Microsoft.AspNetCore.Mvc;
using QuanLyDatVeXeKhach09.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace QuanLyDatVeXeKhach09.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TuyenXeController : ControllerBase
    {
        QuanLyDatVeXeKhachContext da = new QuanLyDatVeXeKhachContext();

        [HttpGet("get-all-route")]
        public IActionResult GetAllTuyenXes()
        {
            var ds = da.TuyenXes.ToList();
            return Ok(ds);
        }

        [HttpGet("get-route-by-id")]
        public IActionResult GetTuyenXeById(int id)
        {
            var ds = da.TuyenXes.FirstOrDefault(s => s.MaTuyen == id);
            return Ok(ds);
        }

        // POST api/<TuyenXeController>
        [HttpPost("add-new-route")]
        public void ThemTuyenXe([FromBody] ThemTuyenXe tuyenXe)
        {
            TuyenXe p = new TuyenXe();
            p.TenTuyen = tuyenXe.TenTuyen;
            p.DiemKhoiHanh = tuyenXe.DiemKhoiHanh;
            p.DiemDen = tuyenXe.DiemDen;
            p.BangGia = tuyenXe.BangGia;
            p.MaXe = tuyenXe.MaXe;

            da.TuyenXes.Add(p);
            da.SaveChanges();
        }

        // PUT api/<TuyenXeController>/5
        [HttpPut("edit-route")]
        public void ThayDoiTuyen(int id, [FromBody] ThayDoiTuyenXe tuyenXe)
        {
            TuyenXe p = da.TuyenXes.FirstOrDefault(s => s.MaTuyen == tuyenXe.MaTuyen);
            p.TenTuyen = tuyenXe.TenTuyen;
            p.DiemKhoiHanh = tuyenXe.DiemKhoiHanh;
            p.DiemDen = tuyenXe.DiemDen;
            p.BangGia = tuyenXe.BangGia;
            p.MaXe = tuyenXe.MaXe;

            da.TuyenXes.Update(p);
            da.SaveChanges();
        }

        // DELETE api/<TuyenXeController>/5
        [HttpDelete("delete-route")]
        public void XoaTuyenXe(int id)
        {
            TuyenXe p = da.TuyenXes.FirstOrDefault(s => s.MaTuyen == id);
            
            da.TuyenXes.Remove(p);
            da.SaveChanges();
        }

        //Thống kê doanh thu theo thang nhập vào
        [HttpPost("total-by-month")]
        public IActionResult CalTotalByMonth(int month)
        {
            var ds = da.ChiTietVeXes.Where(s => s.NgayXuatVe.Value.Month == month)
                .Join(da.ChiTietVeXes, o => o.MaCtvx, d => d.MaCtvx, (o, d) =>
                    new
                    {
                        month = o.NgayXuatVe.Value.Month,
                        total = d.ThanhTien
                    })
                .GroupBy(g => g.month)
                .Select(g => new { g.Key, total = g.Sum(s => s.total) });
            return Ok(ds);
        }

        
    }
}
